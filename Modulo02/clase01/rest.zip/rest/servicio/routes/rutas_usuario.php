<?php 
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
date_default_timezone_set('America/Bogota');
$app = new \Slim\App();
//;

$app->get("/api/usuarios/",function(Request $request, Response $response, array $args){


  $key=$request->getHeaders()["HTTP_KEY"][0];
  
 
  $key_base="knRj8vfCjGkPW8xG59E44D1XdDwU9Onq";

  
 	if($key_base!=$key){
 		echo "{error: {text:No tienes permiso para consumir este recurso}";
 		die();
 	}
 	else{

  

	try{
		$consulta="select * from usuarios";
		$db=new db();
		$db= $db->conectar();	
		$ejecutar = $db->query($consulta);
		$db=null;
		$datos=null;
		foreach ($ejecutar as $key => $value) {
				$datos[]=$value;
		}

		if($datos){
				echo json_encode($datos);	
		}	
		else{
			echo "{error: {text:datos ingresados no son correctos}";
		}
	
		
	}
	catch(\Exception $e){
		echo "{error: {text:".$e->getMessage()."}";
	}


		}


});

$app->post("/api/usuarios/registro",function(Request $request, Response $response, array $args){
		
	 $key=$request->getHeaders()["HTTP_KEY"][0];
 
  $key_base="knRj8vfCjGkPW8xG59E44D1XdDwU9Onq";

   	if($key_base!=$key){
 		echo "{error: {text:No tienes permiso para consumir este recurso}";
 		die();
 	}
 	else{

		$data = $request->getParsedBody();

        $nombres=$data["nombres"];
        $apellidos=$data["apellidos"];
        $correo=$data["correo"];
        $tipo_documento=$data["tipo_documento"];
        $nro_documento=$data["nro_documento"];
        $password=$data["password"];
        $telefono=$data["telefono"];
        $fecha_nacimiento=$data["fecha_nacimiento"];

         $departamento=$data["departamento"];

          $provincia=$data["provincia"];

           $distrito=$data["distrito"];

        $sexo=$data["sexo"];
        $last_login=date('Y-m-d H:i:s');
        $id_facebook=$data["id_facebook"];
        $id_twitter=$data["id_twitter"];
        $fecha_creacion=date('Y-m-d H:i:s');
        $fecha_modificacion=$data["fecha_modificacion"];
        $estado=1;

        if (empty(trim($correo))) {
	
        	echo "{estado: {codigo:0,text:El correo es un campo obligatorio }";
         	die();
		}
		else{
			 preg_match_all("/[\._a-zA-Z0-9-]+@[\._a-zA-Z0-9-]+\.([\._a-zA-Z0-9-])+/i", $correo, $matches);
			if(empty($matches[0])){ 
				echo "{estado: {codigo:0,text:Ingresa un correo valido}";
				die();
    		}
		}

    	$consulta = "INSERT INTO usuarios (nombres, apellidos, correo , tipo_documento, nro_documento, password, telefono, fecha_nacimiento,sexo,departamento,provincia,distrito,last_login , fecha_creacion, fecha_modificacion, id_facebook,id_twitter,estado ) VALUES ('$nombres', '$apellidos','$correo' ,'$tipo_documento', '$nro_documento', '$password', '$telefono', '$fecha_nacimiento', '$sexo',$departamento,$provincia,$distrito, '$last_login', '$fecha_creacion', '$fecha_modificacion', '$id_facebook', '$id_twitter' , '$estado')";

		$db=new db();
		$db= $db->conectar();	
		$ejecutar = $db->query($consulta);
		$db=null;
		if($ejecutar){
			echo "{estado: {codigo:1,text:registro realizado con éxito}";
		}
		else{
			echo "{estado: {codigo:0,text:No se pudo realizar el registro ,revisar los datos ingresados }";
		}

		}



});

$app->get("/api/usuario/",function(Request $request, Response $response, array $args){

	$key=$request->getHeaders()["HTTP_KEY"][0];
 
  $key_base="knRj8vfCjGkPW8xG59E44D1XdDwU9Onq";

   	if($key_base!=$key){
 		echo "{error: {text:No tienes permiso para consumir este recurso}";
 		die();
 	}
 	else{

	$correo=$request->getParam('correo');
	$password=$request->getParam('password');
	
	$db=new db();
	$db= $db->conectar();	

    $correo=$db->real_escape_string($correo);
	$password=$db->real_escape_string($password);

	$consulta="select * from usuarios where correo='$correo' and password='$password'";
		
	$ejecutar = $db->query($consulta);
	$datos=null;
	try{
		foreach ($ejecutar as $key => $value) {
				$datos[]=$value;
		}
		if($datos){
				echo json_encode($datos);	
		}	
		else{
			echo "{error: {text:datos ingresados no son correctos}";
		}
	
	}
	catch(\Exception $e){
		echo "{error: {text:".$e->getMessage()."}";
	}

		}


});

$app->get("/api/usuario/social/",function(Request $request, Response $response, array $args){

	$key=$request->getHeaders()["HTTP_KEY"][0];
 
  $key_base="knRj8vfCjGkPW8xG59E44D1XdDwU9Onq";

   	if($key_base!=$key){
 		echo "{error: {text:No tienes permiso para consumir este recurso}";
 		die();
 	}
 	else{


	$id_facebook=$request->getParam('id_facebook');
	$id_twitter=$request->getParam('id_twitter');

	$db=new db();
	$db= $db->conectar();	

	 $id_facebook=$db->real_escape_string($id_facebook);
	 $id_twitter=$db->real_escape_string($id_twitter);

	if($id_facebook){
	 	$consulta="select * from usuarios where id_facebook='$id_facebook'";
	}
	else if($id_twitter){
		$consulta="select * from usuarios where id_twitter='$id_twitter'";
	}
	else{
		$consulta="";
	}

	$ejecutar = $db->query($consulta);
	$datos=null;
	try{
		foreach ($ejecutar as $key => $value) {
				$datos[]=$value;
		}
		if($datos){
				echo json_encode($datos);	
		}	
		else{
			echo "{error: {text:datos ingresados no son correctos}";
		}
	
	}
	catch(\Exception $e){
		echo "{error: {text:".$e->getMessage()."}";
	}

	}
});

$app->post("/api/usuarios/actualizar",function(Request $request, Response $response, array $args){
		
		
	$key=$request->getHeaders()["HTTP_KEY"][0];
 
  $key_base="knRj8vfCjGkPW8xG59E44D1XdDwU9Onq";

   	if($key_base!=$key){
 		echo "{error: {text:No tienes permiso para consumir este recurso}";
 		die();
 	}
 	else{



		$data = $request->getParsedBody();

        $nombres=$data["nombres"];
        $apellidos=$data["apellidos"];
        $correo=$data["correo"];
        $tipo_documento=$data["tipo_documento"];
        $nro_documento=$data["nro_documento"];
        $password=$data["password"];
        $telefono=$data["telefono"];
        $fecha_nacimiento=$data["fecha_nacimiento"];
        $sexo=$data["sexo"];
        //$last_login=date('Y-m-d H:i:s');
        $id_facebook=$data["id_facebook"];
        $id_twitter=$data["id_twitter"];

        $departamento=$data["departamento"];
        $provincia=$data["provincia"];
        $distrito=$data["distrito"];



        //$fecha_creacion=date('Y-m-d H:i:s');
        $fecha_modificacion=date('Y-m-d H:i:s');
        $estado=1;

        if (empty(trim($correo))) {
	
        	echo "{estado: {codigo:0,text:El correo es un campo obligatorio }";
         	die();
		}
		else{
			 preg_match_all("/[\._a-zA-Z0-9-]+@[\._a-zA-Z0-9-]+\.([\._a-zA-Z0-9-])+/i", $correo, $matches);
			if(empty($matches[0])){ 
				echo "{estado: {codigo:0,text:Ingresa un correo valido}";
				die();
    		}
		}
		$consulta="UPDATE usuarios set nombres='$nombres' , apellidos='$apellidos', tipo_documento='$tipo_documento' , nro_documento ='$nro_documento' , password='$password' , telefono='$telefono' , fecha_nacimiento='$fecha_nacimiento' , sexo='$sexo' , departamento='$departamento' , provincia='$provincia' , distrito='$distrito' , fecha_modificacion='$fecha_modificacion'  where correo='$correo'"; 
 		$db=new db();
		$db= $db->conectar();	
		$ejecutar = $db->query($consulta);
		
		if($db->affected_rows){
			echo "{estado: {codigo:1,text:Los datos se actualizaron sin problemas}";
		}
		else{
			echo "{estado: {codigo:0,text:Los datos se NO se pudieron actualizar}";
		}
		$db=null;


		}


});



?>
