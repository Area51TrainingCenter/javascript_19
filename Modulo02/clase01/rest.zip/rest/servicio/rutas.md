/api/usuario/social/
Login de usuario en base a su ID de redes sociales
**id_facebook**
**id_twitter**

Responde array con valores de usuario


/api/usuario/
Login en base a su correo y contraseña
**correo**
**password**

Responde array con valores de usuario

/api/usuarios/registro
Registro de usuario con los siguientes campos

**nombres**
**apellidos**
**correo**
**tipo_documento**
**nro_documento**
**password**
**telefono**
**fecha_nacimiento**
**sexo**
**id_facebook**
**id_twitter**
**fecha_modificacion**

Responde true/false estado Insert


/api/usuarios/actualizar
Actualiza los campos de usuario con los siguientes campos

**nombres**
**apellidos**
**correo**
**tipo_documento**
**nro_documento**
**password**
**telefono**
**fecha_nacimiento**
**sexo**
**id_facebook**
**id_twitter**
**fecha_modificacion**
con parametro de registro el correo o id
