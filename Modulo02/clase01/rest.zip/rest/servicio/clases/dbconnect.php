<?php
class db{

	private $host="localhost";
	private $user="root";
	private $pass="";
	private $db_name="app_yape";


	public function conectar(){
		$mysqli=new mysqli($this->host,$this->user,$this->pass,$this->db_name);
		$mysqli->query("SET NAMES 'utf8_general_ci'");
		return $mysqli;
	}
}
?>